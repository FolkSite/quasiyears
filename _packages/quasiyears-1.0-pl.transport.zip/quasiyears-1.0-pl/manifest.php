<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '22d22b7bbe0c6321070aac05b0cf006b',
      'native_key' => 'quasiyears',
      'filename' => 'modNamespace/58a14afe5c3404a3ba0fd1167acdf589.vehicle',
      'namespace' => 'quasiyears',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '75cfbdac6f7da2bc51fd4e4aef09d238',
      'native_key' => 1,
      'filename' => 'modCategory/e715dab695d6b46b4100ed8fd24adf99.vehicle',
      'namespace' => 'quasiyears',
    ),
  ),
);